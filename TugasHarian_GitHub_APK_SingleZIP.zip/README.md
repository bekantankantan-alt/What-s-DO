# Tugas Harian — Android APK

Project wrapper Android WebView untuk aplikasi HTML offline.

## Build APK melalui GitHub Actions
1. Extract ZIP.
2. Buat repository GitHub baru dan upload **semua isi folder project** (termasuk folder `.github`).
3. Buka tab **Actions** lalu workflow **Build Tugas Harian APK**.
4. Klik **Run workflow** (atau tunggu build otomatis setelah push ke `main`).
5. Setelah selesai, buka hasil run dan download artifact **Tugas-Harian-debug-apk**. Di dalamnya ada `app-debug.apk`.

APK ini adalah debug build untuk instalasi/testing pribadi. Untuk rilis Play Store atau distribusi luas, perlu signing release.

## Data aplikasi
HTML berada di `app/src/main/assets/index.html`. Ikon launcher disertakan di `app/src/main/res/mipmap-*`.

Catatan: data localStorage WebView tersimpan di perangkat; uninstall aplikasi dapat menghapus data lokal. Informasi akses Wi-Fi yang tertanam di HTML jangan dipublikasikan jika ZIP/repository dibuat publik.
