package com.hasim.whatsdo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TaskWidgetProvider extends AppWidgetProvider {
    public static final String PREFS = "whatsdo_widget_data";
    public static final String TASKS = "tasks_text";

    public static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, TaskWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        if (ids != null && ids.length > 0) {
            new TaskWidgetProvider().onUpdate(context, manager, ids);
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String tasks = prefs.getString(TASKS, "Belum ada tugas harian. Buka aplikasi untuk sinkronisasi.");
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());

        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_tasks);
            views.setTextViewText(R.id.widget_clock, time);
            views.setTextViewText(R.id.widget_tasks_text, tasks);

            String bgPath = prefs.getString("background_path", "");
            if (bgPath != null && !bgPath.isEmpty()) {
                Bitmap bitmap = BitmapFactory.decodeFile(bgPath);
                if (bitmap != null) {
                    int max = 900;
                    if (bitmap.getWidth() > max || bitmap.getHeight() > max) {
                        float scale = Math.min((float) max / bitmap.getWidth(),
                                               (float) max / bitmap.getHeight());
                        Bitmap scaled = Bitmap.createScaledBitmap(bitmap,
                            Math.max(1, Math.round(bitmap.getWidth() * scale)),
                            Math.max(1, Math.round(bitmap.getHeight() * scale)), true);
                        if (scaled != bitmap) bitmap.recycle();
                        bitmap = scaled;
                    }
                    views.setImageViewBitmap(R.id.widget_background, bitmap);
                }
            }

            Intent launch = new Intent(context, MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(context, id, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_root, pi);
            manager.updateAppWidget(id, views);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (Intent.ACTION_TIME_TICK.equals(intent.getAction())
                || Intent.ACTION_TIME_CHANGED.equals(intent.getAction())
                || Intent.ACTION_DATE_CHANGED.equals(intent.getAction())) {
            refresh(context);
        }
    }
}
