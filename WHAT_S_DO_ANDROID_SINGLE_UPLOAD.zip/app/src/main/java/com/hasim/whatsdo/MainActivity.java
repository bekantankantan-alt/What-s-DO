package com.hasim.whatsdo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    public class WidgetBridge {
        @JavascriptInterface public void updateTasks(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                StringBuilder out = new StringBuilder();
                for (int i=0; i<arr.length(); i++) {
                    JSONObject item = arr.optJSONObject(i);
                    if (item == null) continue;
                    String text = item.optString("text", "Tugas").trim();
                    if (text.isEmpty()) continue;
                    if (out.length() > 0) out.append("     •     ");
                    out.append(i+1).append(". ").append(text);
                    String date = item.optString("date", "");
                    if (!date.isEmpty()) out.append(" ( ").append(date).append(" )");
                }
                if (out.length() == 0) out.append("✓ Semua tugas selesai");
                SharedPreferences p = getSharedPreferences(TaskWidgetProvider.PREFS, Context.MODE_PRIVATE);
                p.edit().putString(TaskWidgetProvider.TASKS, out.toString()).apply();
                runOnUiThread(() -> TaskWidgetProvider.refresh(MainActivity.this));
            } catch (Exception ignored) { }
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF063F65);
        getWindow().setNavigationBarColor(0xFF063F65);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setDatabaseEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true); settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new WidgetBridge(), "WhatsDoWidget");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("(function(){function sync(){try{var d=JSON.parse(localStorage.getItem('whatsido_revision2')||'{}');var a=(Array.isArray(d.daily)?d.daily:[]).filter(function(t){return !t.checked&&!t.done&&!t.completed&&Number(t.progress||0)<100}).map(function(t){return {text:String(t.text||t.title||'Tugas').replace(/\\s+/g,' ').trim(),date:t.date||''}});WhatsDoWidget.updateTasks(JSON.stringify(a));}catch(e){}}sync();if(!window.__whatsDoWidgetTimer){window.__whatsDoWidgetTimer=setInterval(sync,2500);var old=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){old.call(this,k,v);if(k==='whatsido_revision2')setTimeout(sync,150);};}})();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
