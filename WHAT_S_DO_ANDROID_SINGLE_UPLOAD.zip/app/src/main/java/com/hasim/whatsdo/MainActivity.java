package com.hasim.whatsdo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.Base64;
import java.io.FileOutputStream;
import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    public class WidgetBridge {
        @JavascriptInterface public void updateBackground(String dataUrl, int x, int y) {
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/")) return;
                int comma = dataUrl.indexOf(',');
                if (comma < 0) return;
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                File file = new File(getFilesDir(), "widget_background.img");
                try (FileOutputStream stream = new FileOutputStream(file)) {
                    stream.write(bytes);
                    stream.flush();
                }
                SharedPreferences p = getSharedPreferences(TaskWidgetProvider.PREFS, Context.MODE_PRIVATE);
                p.edit().putString("background_path", file.getAbsolutePath())
                    .putInt("background_x", Math.max(0, Math.min(100, x)))
                    .putInt("background_y", Math.max(0, Math.min(100, y))).apply();
                runOnUiThread(() -> TaskWidgetProvider.refresh(MainActivity.this));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public void updateDaily(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                StringBuilder out = new StringBuilder();
                int shown = 0;
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject item = arr.optJSONObject(i);
                    if (item == null) continue;
                    int progress = item.has("progress") ? item.optInt("progress", 0) : (item.optBoolean("checked", false) ? 100 : 0);
                    if (item.optBoolean("checked", false) || item.optBoolean("done", false) || item.optBoolean("completed", false) || progress >= 100) continue;
                    String title = item.optString("title", "").trim();
                    String text = item.optString("text", "").trim();
                    String icon = item.optString("icon", "").trim();
                    String date = item.optString("date", "").trim();
                    StringBuilder label = new StringBuilder();
                    if (!icon.isEmpty()) label.append(icon).append(" ");
                    if (!title.isEmpty()) label.append(title);
                    if (!text.isEmpty()) {
                        if (label.length() > 0) label.append(" — ");
                        label.append(text);
                    }
                    if (label.length() == 0) continue;
                    if (out.length() > 0) out.append("\n\n");
                    out.append(String.format(Locale.getDefault(), "%02d", ++shown))
                       .append("  ").append(label);
                    if (!date.isEmpty()) out.append("\n📅  ").append(date);
                }
                if (out.length() == 0) out.append("✓ Tidak ada tugas aktif");
                SharedPreferences p = getSharedPreferences(TaskWidgetProvider.PREFS, Context.MODE_PRIVATE);
                p.edit().putString(TaskWidgetProvider.TASKS, out.toString()).apply();
                runOnUiThread(() -> TaskWidgetProvider.refresh(MainActivity.this));
            } catch (Exception ignored) { }
        }

        // Backward-compatible method name for earlier HTML builds.
        @JavascriptInterface public void updateTasks(String json) { updateDaily(json); }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF063F65);
        getWindow().setNavigationBarColor(0xFF063F65);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setDatabaseEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true); settings.setMediaPlaybackRequiresUserGesture(false);
        WidgetBridge bridge = new WidgetBridge();
        webView.addJavascriptInterface(bridge, "WhatsDoWidget");
        webView.addJavascriptInterface(bridge, "AndroidWidget");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("(function(){try{var k='whatsido_revision2';function sync(){try{var d=JSON.parse(localStorage.getItem(k)||'{}');var a=Array.isArray(d.daily)?d.daily:[];AndroidWidget.updateDaily(JSON.stringify(a));}catch(e){}}sync();if(!window.__whatsDoNativeSync){window.__whatsDoNativeSync=true;var old=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){old.call(this,key,value);if(key===k)setTimeout(sync,100);};}}catch(e){}})();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
