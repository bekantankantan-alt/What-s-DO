package com.hasim.whatsdo;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;
import java.util.List;

public class TaskWidgetService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static class Factory implements RemoteViewsFactory {
        private final Context context;
        private final List<String> items = new ArrayList<>();
        Factory(Context context) { this.context = context; }
        @Override public void onCreate() { load(); }
        @Override public void onDataSetChanged() { load(); }
        @Override public void onDestroy() { items.clear(); }
        @Override public int getCount() { return items.size(); }
        @Override public RemoteViews getViewAt(int position) {
            RemoteViews row = new RemoteViews(context.getPackageName(), R.layout.widget_task_item);
            row.setTextViewText(R.id.widget_task_item, items.get(position));
            return row;
        }
        @Override public RemoteViews getLoadingView() {
            RemoteViews row = new RemoteViews(context.getPackageName(), R.layout.widget_task_item);
            row.setTextViewText(R.id.widget_task_item, "Memuat tugas...");
            return row;
        }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int position) { return position; }
        @Override public boolean hasStableIds() { return true; }

        private void load() {
            items.clear();
            SharedPreferences prefs = context.getSharedPreferences(TaskWidgetProvider.PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString(TaskWidgetProvider.TASKS, "✓ Belum ada tugas tersinkron");
            // Each task paragraph is separated by a blank line by MainActivity.
            String[] tasks = raw.split("\\n\\s*\\n");
            for (String task : tasks) {
                String clean = task.trim();
                if (!clean.isEmpty()) items.add(clean);
            }
            if (items.isEmpty()) items.add("✓ Tidak ada tugas aktif");
        }
    }
}
