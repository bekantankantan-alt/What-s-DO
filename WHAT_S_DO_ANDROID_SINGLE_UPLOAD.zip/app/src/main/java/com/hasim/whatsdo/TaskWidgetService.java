package com.hasim.whatsdo;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;
import java.util.List;

public class TaskWidgetService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static class Factory implements RemoteViewsFactory {
        private final Context context;
        private final List<String> items = new ArrayList<>();
        Factory(Context context) { this.context = context; }
        @Override public void onCreate() { load(); }
        @Override public void onDataSetChanged() { load(); }
        @Override public void onDestroy() { items.clear(); }
        @Override public int getCount() { return items.size(); }
        @Override public RemoteViews getViewAt(int position) {
            RemoteViews row = new RemoteViews(context.getPackageName(), R.layout.widget_task_item);
            row.setTextViewText(R.id.widget_task_item, items.get(position));
            return row;
        }
        @Override public RemoteViews getLoadingView() {
            RemoteViews row = new RemoteViews(context.getPackageName(), R.layout.widget_task_item);
            row.setTextViewText(R.id.widget_task_item, "Memuat tugas...");
            return row;
        }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int position) { return position; }
        @Override public boolean hasStableIds() { return true; }

        private void load() {
            items.clear();
            SharedPreferences prefs = context.getSharedPreferences(TaskWidgetProvider.PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString(TaskWidgetProvider.TASKS, "✓ Semua tugas selesai");
            // Split on the separator character itself; whitespace variations cannot merge tasks.
            String[] tasks = raw.split("\\s*✦\\s*");
            for (String task : tasks) {
                String clean = task.replaceAll("\\s+", " ").trim();
                if (clean.isEmpty()) continue;
                // Show title and date on separate lines, allowing long titles to wrap naturally.
                int dateSeparator = clean.lastIndexOf(" · ");
                if (dateSeparator > 0) {
                    String title = clean.substring(0, dateSeparator).trim();
                    String date = clean.substring(dateSeparator + 3).trim();
                    clean = title + "\n" + date;
                }
                items.add(clean);
            }
            if (items.isEmpty()) items.add("✓ Semua tugas selesai");
        }
    }
}
