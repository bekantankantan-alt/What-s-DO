WHAT'S DO — Android WebView project

Build:
  Java 17
  Gradle 8.9
  Android Gradle Plugin 8.7.3
  Android SDK 35

The HTML app is bundled offline at:
  app/src/main/assets/index.html

GitHub Actions workflow file is supplied separately:
  build.yml

This project builds an installable APK that opens WHAT'S DO as an Android app.
It does not create a native Android home-screen widget.
